at1 type (0: dash, 1: projectile, 2:circle)
at1 direction (0: relative, 1: non_relative)
at1 actual direction (if relative it is char direction + this line)
at1 damage
at1 cooldown
at2 type (0: dash, 1: projectile, 2:circle)
at2 direction (0: relative, 1: non_relative)
at2 actual direction (if relative it is char direction + this line)
at2 damage
at2 cooldown
at3 type (0: dash, 1: projectile, 2:circle)
at3 direction (0: relative, 1: non_relative)                            |if at3type==2 then spin speed
at3 actual direction (if relative it is char direction + this line)     |spin angle change
at3 damage                                                              |spin projectile count
at3 spin damage (if not spin leave this as 0)
at3 cooldown