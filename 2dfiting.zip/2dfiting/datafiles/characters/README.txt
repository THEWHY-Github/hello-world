at1 type (0: dash, 1: projectile, 2:circle)
at1 direction (0: relative, 1: non_relative)
at1 actual direction (if relative it is char direction + this line)
at1 proj (leave blank if none)
at1 cooldown
at2 type (0: dash, 1: projectile, 2:circle)
at2 direction (0: relative, 1: non_relative)
at2 actual direction (if relative it is char direction + this line)
at2 proj (leave blank if none)
at2 cooldown
at3 type (0: dash, 1: projectile, 2:circle)
at3 direction (0: relative, 1: non_relative)                            |if at3type==2 then spin speed
at3 actual direction (if relative it is char direction + this line)     |spin angle change
spin projectile count (leave blank if not needed)
at3 proj (leave blank if none)
at3 cooldown