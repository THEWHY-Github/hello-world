speed
damage
time
relative size